﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using Microsoft.Win32;

namespace AutoPartsWarehouse
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private autoPartsWarehouseDB context = new autoPartsWarehouseDB();
        private salesman thisSalesman;
        private storekeeper thisStorekeeper;
        

        public MainWindow(salesman Salesman = null, storekeeper Storekeeper = null)
        {
            InitializeComponent();

            AcceptAutoPart.IsEnabled = false;

            if (Salesman != null)
            {
                StorekeeperTabItem.IsEnabled = false;
                Change.Visibility = Visibility.Collapsed;
            }
            else if (Storekeeper != null)
            {
                Take.IsEnabled = false;
            }

            thisSalesman = Salesman;
            thisStorekeeper = Storekeeper;

            LoadDataFromDB();
        }

        private void LoadDataFromDB()
        {
            //AutoPartsDG.ItemsSource = context.autopart.Where(x=>!x.isExtradited).ToList();
            
            if(thisStorekeeper == null) AutoPartsDG.ItemsSource = context.autopart.Where(x => x.count != 0).ToList();
            else AutoPartsDG.ItemsSource = context.autopart.ToList();

            ExtraditionDG.ItemsSource = context.extradition.Select(x => new 
            {
                x.idExtradition,
                x.salesman.idSalesman,
                x.autopart.idAutoPart,
                x.salesman.fullname,
                x.salesman.store,
                x.salesman.address,
                x.autopart.title,
                vendorСode = x.autopart.vendorСode,
                x.extraditionDate,
                x.count
            }).ToList();

            AddingDG.ItemsSource = context.addingAutoparts.Select(x => new
            {
                skFullname = x.storekeeper.fullname,
                x.storekeeper.personnelNumber,
                x.autopart.title,
                vendorcode = x.autopart.vendorСode,
                x.addingDate
            }).ToList();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            AuthWindow m = new AuthWindow();
            m.Show();
            this.Close();
        }

        /*private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            if (VendorCodeTB.Text.Trim() == "" && TitleSearchTB.Text.Trim() == "")
                AutoPartsDG.ItemsSource = context.autopart.Where(x => !x.isExtradited).ToList();
            else if (VendorCodeTB.Text.Trim() == "")
                AutoPartsDG.ItemsSource = context.autopart.Where(x => x.title.ToUpper().Contains(TitleSearchTB.Text.ToUpper())).Where(x => !x.isExtradited).ToList();
            else if(TitleSearchTB.Text.Trim() == "")
                AutoPartsDG.ItemsSource = context.autopart.Where(x => x.vendorСode.ToUpper().Contains(VendorCodeTB.Text.ToUpper())).Where(x => !x.isExtradited).ToList();
            else
                AutoPartsDG.ItemsSource = context.autopart.Where(x => x.vendorСode.ToUpper().Contains(VendorCodeTB.Text.ToUpper()) && x.title.ToUpper().Contains(TitleSearchTB.Text.ToUpper())).Where(x => !x.isExtradited).ToList();
        }*/

        private void Take_Click(object sender, RoutedEventArgs e)
        {
            if(AutoPartsDG.SelectedItems.Count != 1)
                { MessageBox.Show("Пожалуйста, выберите запчасть"); return; }    
            autopart ChosPart = (autopart)AutoPartsDG.SelectedItem;

            SelectCountWindow scw = new SelectCountWindow(ChosPart.count);
            if (scw.ShowDialog() == false) return;

            context.extradition.Add(new extradition
            {
                autopart = context.autopart.First(x => x.idAutoPart == ChosPart.idAutoPart),
                salesman = context.salesman.First(x => x.idSalesman == thisSalesman.idSalesman),
                extraditionDate = DateTime.Now,
                count = Convert.ToInt32(scw.Count.Text)
            });
            //context.autopart.First(x => x.idAutoPart == ChosPart.idAutoPart).isExtradited = true;
            context.autopart.First(x => x.idAutoPart == ChosPart.idAutoPart).count -= Convert.ToInt32(scw.Count.Text);
            context.SaveChanges();

            //AutoPartsDG.ItemsSource = context.autopart.Where(x => !x.isExtradited).ToList();
            if (thisStorekeeper == null) AutoPartsDG.ItemsSource = context.autopart.Where(x => x.count != 0).ToList();
            else AutoPartsDG.ItemsSource = context.autopart.ToList();

            ExtraditionDG.ItemsSource = context.extradition.Select(x => new
            {
                x.idExtradition,
                x.salesman.idSalesman,
                x.autopart.idAutoPart,
                x.salesman.fullname,
                x.salesman.store,
                x.salesman.address,
                x.autopart.title,
                vendorСode = x.autopart.vendorСode,
                x.extraditionDate,
                x.count
            }).ToList();
        }

        /*private void ButSearch2_Click(object sender, RoutedEventArgs e)
        {
            if(TBSalesman.Text.Trim() == "")
                ExtraditionDG.ItemsSource = context.extradition.Select(x => new
                {
                    x.idExtradition,
                    x.salesman.idSalesman,
                    x.autopart.idAutoPart,
                    x.salesman.fullname,
                    x.salesman.store,
                    x.salesman.address,
                    x.autopart.title,
                    vendorСode = x.autopart.vendorСode,
                    x.extraditionDate
                }).ToList();
            else 
                ExtraditionDG.ItemsSource = context.extradition.Select(x => new
                {
                    x.idExtradition,
                    x.salesman.idSalesman,
                    x.autopart.idAutoPart,
                    x.salesman.fullname,
                    x.salesman.store,
                    x.salesman.address,
                    x.autopart.title,
                    vendorСode = x.autopart.vendorСode,
                    x.extraditionDate
                }).Where(x => x.fullname.ToUpper().Contains(TBSalesman.Text.ToUpper())).ToList();
        }*/

        private void AddAutoPart_Click(object sender, RoutedEventArgs e)
        {
            var addPart = new AddPartWindow(thisStorekeeper.idStorekeeper);
            addPart.ShowDialog();
            LoadDataFromDB();
        }

        private void AcceptAutoPart_Click(object sender, RoutedEventArgs e)
        {
            if (ExtraditionDG.SelectedItem == null)
            {
                MessageBox.Show("Выберите деталь");
                return;
            }
            dynamic ex = ExtraditionDG.SelectedItem;
            int exID = ex.idExtradition;
            int smID = ex.idSalesman;
            int apID = ex.idAutoPart;

            /*if(context.autopart.First(x => x.idAutoPart == apID).isExtradited == false ||
                context.extradition.Where(x=>x.autopart.idAutoPart == apID).ToList().Last().idExtradition != exID)
            {
                MessageBox.Show("Деталь уже принята");
                return;
            }*/

            context.reception.Add(new reception 
            { 
                receptionDate = DateTime.Now,
                salesman = context.salesman.First(x => x.idSalesman == smID),
                autopart = context.autopart.First(x => x.idAutoPart == apID),
                storekeeper = context.storekeeper.First(x => x.idStorekeeper == thisStorekeeper.idStorekeeper)
            });
            context.autopart.First(x => x.idAutoPart == apID).isExtradited = false;
            context.SaveChanges();
            LoadDataFromDB();
            AcceptAutoPart.IsEnabled = false;
        }

        private void ExtraditionDG_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ExtraditionDG.SelectedItem == null || thisStorekeeper == null) return;

            dynamic ex = ExtraditionDG.SelectedItem;
            int exID = ex.idExtradition;
            int apID = ex.idAutoPart;

            if (context.autopart.First(x => x.idAutoPart == apID).isExtradited == false ||
            context.extradition.Where(x => x.autopart.idAutoPart == apID).ToList().Last().idExtradition != exID)
                AcceptAutoPart.IsEnabled = false;
            else
                AcceptAutoPart.IsEnabled = true;
        }


        /*private void StockSpareParts_Click(object sender, RoutedEventArgs e)
        {
            var StParts = context.autopart.ToList();

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workBook;
            Excel.Worksheet workSheet;
            excelApp.SheetsInNewWorkbook = 1;

            workBook = excelApp.Workbooks.Add();
            workSheet = (Excel.Worksheet)workBook.Worksheets.get_Item(1);
            workSheet.Name = "Запчасти в наличии";
            workSheet.Cells[1, 1] = "Запчасти в наличии";
            workSheet.Cells[2, 1] = "№ запчасти";
            workSheet.Cells[2, 2] = "Производитель";
            workSheet.Cells[2, 3] = "Название";
            workSheet.Cells[2, 4] = "Артикул";
            workSheet.Cells[2, 5] = "Год выпуска";

            for (int i = 0; i < StParts.Count; i++)
            {
                var path = StParts[i];
                workSheet.Cells[i + 3, 1] = path.idAutoPart;
                workSheet.Cells[i + 3, 2] = path.manufacturer;
                workSheet.Cells[i + 3, 3] = path.title;
                workSheet.Cells[i + 3, 4] = path.vendorСode;
                workSheet.Cells[i + 3, 5] = path.manufactureYear;
            }
            workSheet.Cells[StParts.Count + 4, 1] = "Общее количество " + StParts.Count;
            workBook.Saved = true;
            excelApp.DisplayAlerts = false;
            workBook.Save(); //документ сохранился в папке Документы с именем по умолчанию
            excelApp.Visible = true;
            // excelApp.Quit();
        }

        private void IssuedSpareParts_Click(object sender, RoutedEventArgs e)
        {
            var StParts = context.extradition.ToList();
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workBook;
            Excel.Worksheet workSheet;
            excelApp.SheetsInNewWorkbook = 1;

            workBook = excelApp.Workbooks.Add();
            workSheet = (Excel.Worksheet)workBook.Worksheets.get_Item(1);
            workSheet.Name = "Выданные запчасти";
            workSheet.Cells[1, 1] = "Выданные запчасти";
            workSheet.Cells[2, 1] = "№ запчасти";
            workSheet.Cells[2, 2] = "Производитель";
            workSheet.Cells[2, 3] = "Название";
            workSheet.Cells[2, 4] = "Артикул";
            workSheet.Cells[2, 5] = "Год выпуска";

            for (int i = 0; i < StParts.Count; i++)
            {
                var path = StParts[i];
                workSheet.Cells[i + 3, 1] = path.autopart.idAutoPart;
                workSheet.Cells[i + 3, 2] = path.autopart.manufacturer;
                workSheet.Cells[i + 3, 3] = path.autopart.title;
                workSheet.Cells[i + 3, 4] = path.autopart.vendorСode;
                workSheet.Cells[i + 3, 5] = path.autopart.manufactureYear;
            }
            workSheet.Cells[StParts.Count + 4, 1] = "Общее количество " + StParts.Count;
            workBook.Saved = true;
            excelApp.DisplayAlerts = false;
            workBook.Save(); //документ сохранился в папке Документы с именем по умолчанию
            excelApp.Visible = true;
            // excelApp.Quit();

        }

        private void SellerList_click(object sender, RoutedEventArgs e)
        {
            var SelList = context.salesman.ToList();

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workBook;
            Excel.Worksheet workSheet;
            excelApp.SheetsInNewWorkbook = 1;

            workBook = excelApp.Workbooks.Add();
            workSheet = (Excel.Worksheet)workBook.Worksheets.get_Item(1);
            workSheet.Name = "Список продавцов";
            workSheet.Cells[1, 1] = "Список продавцов";
            workSheet.Cells[2, 1] = "№ продавца";
            workSheet.Cells[2, 2] = "ФИО";
            workSheet.Cells[2, 3] = "Магазин";
            workSheet.Cells[2, 4] = "Адрес магазина";

            for (int i = 0; i < SelList.Count; i++)
            {
                var path = SelList[i];
                workSheet.Cells[i + 3, 1] = path.idSalesman;
                workSheet.Cells[i + 3, 2] = path.fullname;
                workSheet.Cells[i + 3, 3] = path.store;
                workSheet.Cells[i + 3, 4] = path.address;
            }
            workSheet.Cells[SelList.Count + 4, 1] = "Общее количество " + SelList.Count;
            workBook.Saved = true;
            excelApp.DisplayAlerts = false;
            workBook.Save(); //документ сохранился в папке Документы с именем по умолчанию
            excelApp.Visible = true;
            // excelApp.Quit();
        }

        private void StorekeepersList_Click(object sender, RoutedEventArgs e)
        {
            var StkeepList = context.storekeeper.ToList();

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workBook;
            Excel.Worksheet workSheet;
            excelApp.SheetsInNewWorkbook = 1;

            workBook = excelApp.Workbooks.Add();
            workSheet = (Excel.Worksheet)workBook.Worksheets.get_Item(1);
            workSheet.Name = "Список кладовщиков";
            workSheet.Cells[1, 1] = "Список кладовщиков";
            workSheet.Cells[2, 1] = "№ кладовщика";
            workSheet.Cells[2, 2] = "ФИО";
            workSheet.Cells[2, 3] = "Табельный номер";

            for (int i = 0; i < StkeepList.Count; i++)
            {
                var path = StkeepList[i];
                workSheet.Cells[i + 3, 1] = path.idStorekeeper;
                workSheet.Cells[i + 3, 2] = path.fullname;
                workSheet.Cells[i + 3, 3] = path.personnelNumber;
            }
            workSheet.Cells[StkeepList.Count + 4, 1] = "Общее количество " + StkeepList.Count;
            workBook.Saved = true;
            excelApp.DisplayAlerts = false;
            workBook.Save(); //документ сохранился в папке Документы с именем по умолчанию
            excelApp.Visible = true;
            // excelApp.Quit();
        }*/

        private void VendorCodeTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            Search();
        }

        void Search()
        {
            if (VendorCodeTB.Text.Length > 2 && TitleSearchTB.Text.Length > 2)
            {
                if (thisStorekeeper == null) AutoPartsDG.ItemsSource = context.autopart.Where(x => x.vendorСode.ToUpper().Contains(VendorCodeTB.Text.ToUpper()) && x.title.ToUpper().Contains(TitleSearchTB.Text.ToUpper())).Where(x => x.count != 0).ToList();
                else AutoPartsDG.ItemsSource = context.autopart.Where(x => x.vendorСode.ToUpper().Contains(VendorCodeTB.Text.ToUpper()) && x.title.ToUpper().Contains(TitleSearchTB.Text.ToUpper())).ToList();
            }
            else if (VendorCodeTB.Text.Length > 2)
            {
                if (thisStorekeeper == null) AutoPartsDG.ItemsSource = context.autopart.Where(x => x.vendorСode.ToUpper().Contains(VendorCodeTB.Text.ToUpper())).Where(x => x.count != 0).ToList();
                else AutoPartsDG.ItemsSource = context.autopart.Where(x => x.vendorСode.ToUpper().Contains(VendorCodeTB.Text.ToUpper())).ToList();
            }
            else if (TitleSearchTB.Text.Length > 2)
            {
                if (thisStorekeeper == null) AutoPartsDG.ItemsSource = context.autopart.Where(x => x.title.ToUpper().Contains(TitleSearchTB.Text.ToUpper())).Where(x => x.count != 0).ToList();
                else AutoPartsDG.ItemsSource = context.autopart.Where(x => x.title.ToUpper().Contains(TitleSearchTB.Text.ToUpper())).ToList();
            }
            else
            {
                if (thisStorekeeper == null) AutoPartsDG.ItemsSource = context.autopart.Where(x => x.count != 0).ToList();
                else AutoPartsDG.ItemsSource = context.autopart.ToList();
            }
        }

        private void TBSalesman_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TBSalesman.Text.Length < 3)
                ExtraditionDG.ItemsSource = context.extradition.Select(x => new
                {
                    x.idExtradition,
                    x.salesman.idSalesman,
                    x.autopart.idAutoPart,
                    x.salesman.fullname,
                    x.salesman.store,
                    x.salesman.address,
                    x.autopart.title,
                    vendorСode = x.autopart.vendorСode,
                    x.extraditionDate,
                    x.count
                }).ToList();
            else
                ExtraditionDG.ItemsSource = context.extradition.Select(x => new
                {
                    x.idExtradition,
                    x.salesman.idSalesman,
                    x.autopart.idAutoPart,
                    x.salesman.fullname,
                    x.salesman.store,
                    x.salesman.address,
                    x.autopart.title,
                    vendorСode = x.autopart.vendorСode,
                    x.extraditionDate,
                    x.count
                }).Where(x => x.fullname.ToUpper().Contains(TBSalesman.Text.ToUpper())).ToList();
        }

        private void ChangeCount_Click(object sender, RoutedEventArgs e)
        {
            if (AutoPartsDG.SelectedItems.Count != 1)
            { MessageBox.Show("Пожалуйста, выберите запчасть"); return; }
            autopart ChosPart = (autopart)AutoPartsDG.SelectedItem;

            SelectCountWindow scw = new SelectCountWindow(1000000000);
            if (scw.ShowDialog() == false) return;

            ChosPart.count = Convert.ToInt32(scw.Count.Text);

            context.SaveChanges();

            AutoPartsDG.ItemsSource = context.autopart.ToList();
        }

        private void ImportAutoParts_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Файл Excel|*.xls;*.xlsx;*.xlsm";
            if (openFileDialog.ShowDialog() == true)
            {
                Excel.Application excel = new Excel.Application();
                Excel.Workbook excelWorkbook = excel.Workbooks.Open(openFileDialog.FileName, Type.Missing, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, true, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                Excel._Worksheet excelWorksheet = excelWorkbook.Sheets[1];

                int manufColumn = -1;
                int titleColumn = -1;
                int vendorColumn = -1;
                int yearColumn = -1;
                int countColumn = -1;

                for(int i = 1; i <= 5; i++)
                {
                    for (int j = 1; j <= 5; j++)
                    {
                        if (i == 1 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "производитель") { manufColumn = j; break; }
                        if (i == 2 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "название") { titleColumn = j; break; }
                        if (i == 3 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "артикул") { vendorColumn = j; break; }
                        if (i == 4 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "год выпуска") { yearColumn = j; break; }
                        if (i == 5 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "количество") { countColumn = j; break; }
                    }
                }

                if(manufColumn == -1 || titleColumn == -1 || vendorColumn == -1 || yearColumn == -1 || countColumn == -1)
                {
                    MessageBox.Show("Выбранный файл не соответствует необходимому формату");
                    excel.Quit();
                    return;
                }

                for (int i = 1; i <= 5; i++)
                {
                    for (int j = 1; j <= 5; j++)
                    {
                        if (i == 1 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "производитель") { manufColumn = j; break; }
                        if (i == 2 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "название") { titleColumn = j; break; }
                        if (i == 3 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "артикул") { vendorColumn = j; break; }
                        if (i == 4 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "год выпуска") { yearColumn = j; break; }
                        if (i == 5 && (excelWorksheet.Cells[1, j] as Excel.Range).Value.ToLower().Trim() == "количество") { countColumn = j; break; }
                    }
                }

                int lastUsedRow = excelWorksheet.Cells.Find("*", System.Reflection.Missing.Value,
                               System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                               Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlPrevious,
                               false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;

                for(int row = 2; row <= lastUsedRow; row++)
                {
                    string manufacturer = (excelWorksheet.Cells[row, manufColumn] as Excel.Range).Value;
                    string title = (excelWorksheet.Cells[row, titleColumn] as Excel.Range).Value;
                    string vendorСode = (excelWorksheet.Cells[row, vendorColumn] as Excel.Range).Value;
                    int manufactureYear = Convert.ToInt32((excelWorksheet.Cells[row, yearColumn] as Excel.Range).Value);
                    int count = Convert.ToInt32((excelWorksheet.Cells[row, countColumn] as Excel.Range).Value);

                    autopart eAp = context.autopart.FirstOrDefault(x => x.manufacturer == manufacturer && x.title == title && x.vendorСode == vendorСode && x.manufactureYear == manufactureYear);

                    if(eAp != null)
                    {
                        eAp.count += count;
                        context.SaveChanges();
                    }
                    else
                    {
                        autopart ap = context.autopart.Add(new autopart()
                        {
                            manufacturer = manufacturer,
                            title = title,
                            vendorСode = vendorСode,
                            manufactureYear = manufactureYear,
                            count = count,
                            isExtradited = false
                        });

                        context.SaveChanges();

                        context.addingAutoparts.Add(new addingAutoparts
                        {
                            autopart = context.autopart.First(x => x.idAutoPart == ap.idAutoPart),
                            storekeeper = context.storekeeper.First(x => x.idStorekeeper == thisStorekeeper.idStorekeeper),
                            addingDate = DateTime.Now
                        });

                        context.SaveChanges();
                    }
                }

                LoadDataFromDB();

                excel.Quit();
            }
        }

        class requestRow
        {
            public autopart a;
            public addingAutoparts aap;
            public storekeeper sk;
            public extradition ex;
            public salesman sm;
        }

        private void OpenReport_Click(object sender, RoutedEventArgs e)
        {
            var request = GetRequest();

            if (GetRequest() == null) return;

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workBook;
            Excel.Worksheet workSheet;
            excelApp.SheetsInNewWorkbook = 1;

            workBook = excelApp.Workbooks.Add();
            workSheet = (Excel.Worksheet)workBook.Worksheets.get_Item(1);
            workSheet.Name = "Отчёт";

            int i = 1;

            //ЗАПЧАСТИ
            if (Autopart_IdCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Autopart_IdCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.a?.idAutoPart.ToString()).ToList()); i++;
            }
            if (Autopart_ManufacturerCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Autopart_ManufacturerCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.a?.manufacturer.ToString()).ToList()); i++;
            }
            if (Autopart_TitleCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Autopart_TitleCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.a?.title.ToString()).ToList()); i++;
            }
            if (Autopart_VendorCodeCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Autopart_VendorCodeCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.a?.vendorСode.ToString()).ToList()); i++;
            }
            if (Autopart_ManufacturerYearCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Autopart_ManufacturerYearCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.a?.manufactureYear.ToString()).ToList()); i++;
            }
            if (Autopart_CountCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Autopart_CountCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.a?.count.ToString()).ToList()); i++;
            }

            //ВЫДАЧИ
            if (Extradition_IdCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Extradition_IdCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.ex?.idExtradition.ToString()).ToList()); i++;
            }
            if (Extradition_DateCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Extradition_DateCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.ex?.extraditionDate.ToString()).ToList()); i++;
            }
            if (Extradition_CountCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Extradition_CountCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.ex?.count.ToString()).ToList()); i++;
            }

            //ДОБАВЛЕНИЯ
            if (Adding_IdCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Adding_IdCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.aap?.idAdding.ToString()).ToList()); i++;
            }
            if (Adding_DateCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Adding_DateCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.aap?.addingDate.ToString()).ToList()); i++;
            }

            //ПОКУПАТЕЛИ
            if (Salesman_IdCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Salesman_IdCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sm?.idSalesman.ToString()).ToList()); i++;
            }
            if (Salesman_FullnameCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Salesman_FullnameCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sm?.fullname.ToString()).ToList()); i++;
            }
            if (Salesman_StoreCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Salesman_StoreCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sm?.store.ToString()).ToList()); i++;
            }
            if (Salesman_AddressCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Salesman_AddressCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sm?.address.ToString()).ToList()); i++;
            }
            if (Salesman_LoginCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Salesman_LoginCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sm?.login.ToString()).ToList()); i++;
            }
            if (Salesman_PasswordCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Salesman_PasswordCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sm?.password.ToString()).ToList()); i++;
            }

            //КЛАДОВЩИКИ
            if (Storekeeper_IdCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Storekeeper_IdCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sk?.idStorekeeper.ToString()).ToList()); i++;
            }
            if (Storekeeper_FullnameCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Storekeeper_FullnameCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sk?.fullname.ToString()).ToList()); i++;
            }
            if (Storekeeper_PersonnelNumberCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Storekeeper_PersonnelNumberCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sk?.personnelNumber.ToString()).ToList()); i++;
            }
            if (Storekeeper_LoginCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Storekeeper_LoginCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sk?.login.ToString()).ToList()); i++;
            }
            if (Storekeeper_PasswordCb.IsChecked == true)
            {
                workSheet.Cells[1, i] = Storekeeper_PasswordCb.Content;
                WriteColumn(workSheet, i, request.Select(x => x.sk?.password.ToString()).ToList()); i++;
            }

            for (int j = 1; j < i; j++)
            {
                Excel.Range cell = workSheet.Cells[1, j];
                Excel.Borders border = cell.Borders;
                border.LineStyle = Excel.XlLineStyle.xlContinuous;
                border.Weight = 2d;
            }

            workSheet.Range[workSheet.Columns[1], workSheet.Columns[i]].AutoFit();
            workSheet.Cells[1, 1].EntireRow.Font.Bold = true;

            workBook.Saved = true;
            excelApp.DisplayAlerts = false;
            workBook.Save();
            excelApp.Visible = true;
        }

        void WriteColumn(Excel.Worksheet workSheet, int column, List<string> content)
        {
            for(int i = 0; i < content.Count; i++)
            {
                workSheet.Cells[i + 2, column] = content[i];

                Excel.Range cell = workSheet.Cells[i + 2, column];
                Excel.Borders border = cell.Borders;
                border.LineStyle = Excel.XlLineStyle.xlContinuous;
                border.Weight = 2d;
            }
        }

        List<requestRow> GetRequest()
        {
            bool inclAutoparts = false;
            bool inclExtraditions = false;
            bool inclSalesmans = false;
            bool inclStorekeepers = false;
            bool inclAddings = false;

            foreach(CheckBox cb in AutopartsSp.Children)
            {
                if(cb.IsChecked == true) { inclAutoparts = true; break; }
            }

            foreach (CheckBox cb in ExtraditionsSp.Children)
            {
                if (cb.IsChecked == true) { inclExtraditions = true; break; }
            }

            foreach (CheckBox cb in SalesmansSp.Children)
            {
                if (cb.IsChecked == true) { inclSalesmans = true; break; }
            }

            foreach (CheckBox cb in StorekeepersSp.Children)
            {
                if (cb.IsChecked == true) { inclStorekeepers = true; break; }
            }

            foreach (CheckBox cb in AddingsSp.Children)
            {
                if (cb.IsChecked == true) { inclAddings = true; break; }
            }

            if(inclAutoparts)
            {
                if ((inclExtraditions || inclSalesmans) && (inclAddings || inclStorekeepers))
                {
                    var request =
                    (
                        from a in context.autopart
                        join sub1 in context.addingAutoparts on a.idAutoPart equals sub1.autopart.idAutoPart into q1
                        from aap in q1.DefaultIfEmpty()
                        join sub2 in context.storekeeper on aap.storekeeper.idStorekeeper equals sub2.idStorekeeper into q2
                        from sk in q2.DefaultIfEmpty()
                        join sub3 in context.extradition on a.idAutoPart equals sub3.autopart.idAutoPart into q3
                        from ex in q3.DefaultIfEmpty()
                        join sub4 in context.salesman on ex.salesman.idSalesman equals sub4.idSalesman into q4
                        from sm in q4.DefaultIfEmpty()
                        select new { a, aap, sk, ex, sm }
                    );

                    List<requestRow> res = new List<requestRow>();
                    foreach(var v in request)
                    {
                        res.Add(new requestRow() { a = v.a, aap = v.aap, ex = v.ex, sk = v.sk, sm = v.sm });
                    }

                    return res;
                }
                else if (inclAddings || inclStorekeepers)
                {
                    var request =
                    (
                        from a in context.autopart
                        join sub1 in context.addingAutoparts on a.idAutoPart equals sub1.autopart.idAutoPart into q1
                        from aap in q1.DefaultIfEmpty()
                        join sub2 in context.storekeeper on aap.storekeeper.idStorekeeper equals sub2.idStorekeeper into q2
                        from sk in q2.DefaultIfEmpty()
                        select new { a, aap, sk }
                    );

                    List<requestRow> res = new List<requestRow>();
                    foreach (var v in request)
                    {
                        res.Add(new requestRow() { a = v.a, aap = v.aap, ex = null, sk = v.sk, sm = null });
                    }

                    return res;
                }
                else if (inclExtraditions || inclSalesmans)
                {
                    var request =
                    (
                        from a in context.autopart
                        join sub3 in context.extradition on a.idAutoPart equals sub3.autopart.idAutoPart into q3
                        from ex in q3.DefaultIfEmpty()
                        join sub4 in context.salesman on ex.salesman.idSalesman equals sub4.idSalesman into q4
                        from sm in q4.DefaultIfEmpty()
                        select new { a, ex, sm }
                    );

                    List<requestRow> res = new List<requestRow>();
                    foreach (var v in request)
                    {
                        res.Add(new requestRow() { a = v.a, aap = null, ex = v.ex, sk = null, sm = v.sm });
                    }

                    return res;
                }
                else
                {
                    List<requestRow> res = new List<requestRow>();
                    foreach (var v in context.autopart.ToList())
                    {
                        res.Add(new requestRow() { a = v, aap = null, ex = null, sk = null, sm = null });
                    }

                    return res;
                }
            }
            else if((inclExtraditions || inclSalesmans) && (inclAddings || inclStorekeepers))
            {
                var request =
                    (
                        from a in context.autopart
                        join sub1 in context.addingAutoparts on a.idAutoPart equals sub1.autopart.idAutoPart into q1
                        from aap in q1.DefaultIfEmpty()
                        join sub2 in context.storekeeper on aap.storekeeper.idStorekeeper equals sub2.idStorekeeper into q2
                        from sk in q2.DefaultIfEmpty()
                        join sub3 in context.extradition on a.idAutoPart equals sub3.autopart.idAutoPart into q3
                        from ex in q3.DefaultIfEmpty()
                        join sub4 in context.salesman on ex.salesman.idSalesman equals sub4.idSalesman into q4
                        from sm in q4.DefaultIfEmpty()
                        select new { a, aap, sk, ex, sm }
                    );

                List<requestRow> res = new List<requestRow>();
                foreach (var v in request)
                {
                    res.Add(new requestRow() { a = v.a, aap = v.aap, ex = v.ex, sk = v.sk, sm = v.sm });
                }

                return res;
            }
            else if (inclAddings || inclStorekeepers)
            {
                if (!inclAddings)
                {
                    var requestq =
                    (
                        from sk in context.storekeeper
                        select new { sk }
                    );

                    List<requestRow> resq = new List<requestRow>();
                    foreach (var v in requestq)
                    {
                        resq.Add(new requestRow() { a = null, aap = null, ex = null, sk = v.sk, sm = null });
                    }

                    return resq;
                }

                var request =
                (
                    from aap in context.addingAutoparts
                    join sub2 in context.storekeeper on aap.storekeeper.idStorekeeper equals sub2.idStorekeeper into q2
                    from sk in q2.DefaultIfEmpty()
                    select new { aap, sk }
                );

                List<requestRow> res = new List<requestRow>();
                foreach (var v in request)
                {
                    res.Add(new requestRow() { a = null, aap = v.aap, ex = null, sk = v.sk, sm = null });
                }

                return res;
            }
            else if (inclExtraditions || inclSalesmans)
            {
                if(!inclExtraditions)
                {
                    var requestq =
                    (
                        from sm in context.salesman
                        select new { sm }
                    );

                    List<requestRow> resq = new List<requestRow>();
                    foreach (var v in requestq)
                    {
                        resq.Add(new requestRow() { a = null, aap = null, ex = null, sk = null, sm = v.sm });
                    }

                    return resq;
                }

                var request =
                (
                    from ex in context.extradition
                    join sub4 in context.salesman on ex.salesman.idSalesman equals sub4.idSalesman into q4
                    from sm in q4.DefaultIfEmpty()
                    select new { ex, sm }
                );

                List<requestRow> res = new List<requestRow>();
                foreach (var v in request)
                {
                    res.Add(new requestRow() { a = null, aap = null, ex = v.ex, sk = null, sm = v.sm });
                }

                return res;
            }
            else
                return null;
        }
    }
}
