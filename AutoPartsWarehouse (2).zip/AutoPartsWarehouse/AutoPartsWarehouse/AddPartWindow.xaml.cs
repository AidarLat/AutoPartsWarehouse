﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AutoPartsWarehouse
{
    /// <summary>
    /// Логика взаимодействия для AddPartWindow.xaml
    /// </summary>
    public partial class AddPartWindow : Window
    {
        int skId;
        public AddPartWindow(int skId)
        {
            InitializeComponent();

            this.skId = skId;

            autoPartsWarehouseDB db = new autoPartsWarehouseDB();

            List<string> manufs = new List<string>();

            Dictionary<string, int> mc = new Dictionary<string, int>();

            foreach (string m in db.autopart.Select(x => x.manufacturer).ToList())
            {
                if (mc.Keys.Contains(m)) mc[m]++;
                else mc.Add(m, 1);
            }

            foreach(string m in mc.OrderByDescending(x => x.Value).Select(x => x.Key))
            {
                if (manufs.Count == 11) break;

                manufs.Add(m);
            }

            ManufAdd.ItemsSource = manufs;
        }

        private void AddPart_Click(object sender, RoutedEventArgs e)
        {
            int year = 0;
            if (TitlePartAdd.Text.Trim() == "")
                { MessageBox.Show("Введите название запчасти"); return; }
            else if (ManufAdd.Text.Trim() == "")
                { MessageBox.Show("Введите производителя"); return; }
            else if (VendorAdd.Text.Trim() == "")
                { MessageBox.Show("Введите артикул"); return; }
            else if (YearAdd.Text.Trim() == "")
                { MessageBox.Show("Введите год выпуска"); return; }
            else if (CountAdd.Text.Trim() == "")
                { MessageBox.Show("Введите количество"); return; }
            else if (!int.TryParse(YearAdd.Text, out year))
                { MessageBox.Show("Год выпуска должен быть числом"); return; }
            else if (!isInputCorrect())
                { MessageBox.Show("Количество должно быть числом"); return; }


            autoPartsWarehouseDB context = new autoPartsWarehouseDB();
            autopart ap = context.autopart.Add(new autopart 
            { 
                title = TitlePartAdd.Text,
                manufacturer = ManufAdd.Text,
                vendorСode = VendorAdd.Text,
                manufactureYear = year,
                count = Convert.ToInt32(CountAdd.Text)
            });
            context.SaveChanges();

            context.addingAutoparts.Add(new addingAutoparts
            {
                autopart = context.autopart.First(x => x.idAutoPart == ap.idAutoPart),
                storekeeper = context.storekeeper.First(x => x.idStorekeeper == skId),
                addingDate = DateTime.Now
            });
            context.SaveChanges();

            this.Close();
        }

        bool isInputCorrect()
        {
            bool res = true;
            foreach (char c in CountAdd.Text)
            {
                if (!char.IsDigit(c)) res = false;
            }

            return res;
        }

        private void TitlePartAdd_GotFocus(object sender, RoutedEventArgs e)
        {
            if(TitlePartAdd.Text == "Введите название:") TitlePartAdd.Text = "";
        }

        private void TitlePartAdd_LostFocus(object sender, RoutedEventArgs e)
        {
            if (TitlePartAdd.Text.Trim() == "") TitlePartAdd.Text = "Введите название:";
        }

        private void ManufAdd_GotFocus(object sender, RoutedEventArgs e)
        {
            if (ManufAdd.Text == "Введите производителя:") ManufAdd.Text = "";
        }

        private void ManufAdd_LostFocus(object sender, RoutedEventArgs e)
        {
            if (ManufAdd.Text.Trim() == "") ManufAdd.Text = "Введите производителя:";
        }

        private void VendorAdd_GotFocus(object sender, RoutedEventArgs e)
        {
            if (VendorAdd.Text == "Введите артикул:") VendorAdd.Text = "";
        }

        private void VendorAdd_LostFocus(object sender, RoutedEventArgs e)
        {
            if (VendorAdd.Text.Trim() == "") VendorAdd.Text = "Введите артикул:";
        }

        private void YearAdd_GotFocus(object sender, RoutedEventArgs e)
        {
            if (YearAdd.Text == "Введите год выпуска:") YearAdd.Text = "";
        }

        private void YearAdd_LostFocus(object sender, RoutedEventArgs e)
        {
            if (YearAdd.Text.Trim() == "") YearAdd.Text = "Введите год выпуска:";
        }

        private void CountAdd_GotFocus(object sender, RoutedEventArgs e)
        {
            if (CountAdd.Text == "Введите количество:") CountAdd.Text = "";
        }

        private void CountAdd_LostFocus(object sender, RoutedEventArgs e)
        {
            if (CountAdd.Text.Trim() == "") CountAdd.Text = "Введите количество:";
        }
    }
}
