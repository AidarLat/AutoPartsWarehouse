﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AutoPartsWarehouse
{
    /// <summary>
    /// Логика взаимодействия для SelectCountWindow.xaml
    /// </summary>
    public partial class SelectCountWindow : Window
    {
        int max;
        public SelectCountWindow(int max)
        {
            InitializeComponent();

            this.max = max;
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            if (Count.Text.Trim() == "1") return;
            if (isInputCorrect()) Count.Text = (Convert.ToInt32(Count.Text) - 1).ToString();
            else Count.Text = "1";
        }

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            if (isInputCorrect())
            {
                if(Convert.ToInt32(Count.Text) + 1 <= max)
                    Count.Text = (Convert.ToInt32(Count.Text) + 1).ToString();
            }
            else Count.Text = "1";
        }

        private void AddPart_Click(object sender, RoutedEventArgs e)
        {
            if(!isInputCorrect())
            {
                MessageBox.Show("Количество запчастей должно быть числом");
                return;
            }

            if(Convert.ToInt32(Count.Text) > max)
            {
                MessageBox.Show("Нельзя взять больше запчастей, чем имеется на складе. Запчастей на складе " + max);
                return;
            }

            this.DialogResult = true;
        }

        bool isInputCorrect()
        {
            
            bool res = true;
            foreach(char c in Count.Text)
            {
                if (!char.IsDigit(c)) res = false;
            }

            return res;
        }
    }
}
