﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AutoPartsWarehouse
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class AuthWindow : Window
    {
        int numberloginpassword = 0;
        autoPartsWarehouseDB context = new autoPartsWarehouseDB();
        public AuthWindow()
        {
            InitializeComponent();
        }

        private void EnterBut_Click(object sender, RoutedEventArgs e)
        {
            if (LoginTB.Text == "" || PasswordTB.Text == "")
            {
                MessageBox.Show("Не введён логин или пароль");
                return;
            }
            if (numberloginpassword >= 3)
            {
                var cap = new CAPTCHAWindow();
                cap.ShowDialog();
                if (cap.IsAccept == false)
                {
                    MessageBox.Show("Captcha не введена");
                    return;
                }
            }
            var salesman = context.salesman.FirstOrDefault(x => x.login == LoginTB.Text);
            var storekeeper = context.storekeeper.FirstOrDefault(x => x.login == LoginTB.Text);

            if (PasswordTB.Visibility == Visibility.Visible)
            {
                PasswordPB.Password = PasswordTB.Text;
            }
            else
            {
                PasswordTB.Text = PasswordPB.Password;
            }

            if (salesman?.password == PasswordTB.Text || storekeeper?.password == PasswordTB.Text)
            {
                new MainWindow(salesman, storekeeper).Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Введён неверный логин или пароль");
                numberloginpassword++;
            }
        }

        private void Show_Click(object sender, RoutedEventArgs e)
        {
            if(PasswordTB.Visibility == Visibility.Visible)
            {
                if (PasswordTB.Text != "Введите пароль") PasswordPB.Password = PasswordTB.Text;
                else PasswordPB.Password = "";
                PasswordPB.Focus();
                PasswordTB.Visibility = Visibility.Collapsed;
                if(PasswordPB.Password.Trim() == "")
                {
                    PreviewPasswordPB.Visibility = Visibility.Visible;
                    PasswordPB.Visibility = Visibility.Collapsed;
                }
                else 
                {
                    PasswordPB.Visibility = Visibility.Visible;
                    PreviewPasswordPB.Visibility = Visibility.Collapsed;
                }
            }
            else
            {
                PasswordTB.Text = PasswordPB.Password;
                PasswordTB.Focus();
                PasswordTB.Visibility = Visibility.Visible;
                PasswordPB.Visibility = Visibility.Collapsed;
                PreviewPasswordPB.Visibility = Visibility.Collapsed;
            }
        }

        private void LoginTB_GotFocus(object sender, RoutedEventArgs e)
        {
            if(LoginTB.Text == "Введите логин") LoginTB.Text = "";
        }

        private void LoginTB_LostFocus(object sender, RoutedEventArgs e)
        {
            if (LoginTB.Text.Trim() == "") LoginTB.Text = "Введите логин";
        }

        private void PasswordTB_GotFocus(object sender, RoutedEventArgs e)
        {
            if (PasswordTB.Text == "Введите пароль") PasswordTB.Text = "";
        }

        private void PasswordTB_LostFocus(object sender, RoutedEventArgs e)
        {
            if (PasswordTB.Text.Trim() == "") PasswordTB.Text = "Введите пароль";
        }

        private void PasswordPB_GotFocus(object sender, RoutedEventArgs e)
        {

        }

        private void PasswordPB_LostFocus(object sender, RoutedEventArgs e)
        {
            if (PasswordPB.Password.Trim() == "") 
            { 
                PreviewPasswordPB.Visibility = Visibility.Visible; 
                PasswordPB.Visibility = Visibility.Collapsed; 
            }
        }

        private void PreviewPasswordPB_GotFocus(object sender, RoutedEventArgs e)
        {
            PreviewPasswordPB.Visibility = Visibility.Collapsed;
            PasswordPB.Visibility = Visibility.Visible;
            PasswordPB.Focus();
        }

        private void PreviewPasswordPB_LostFocus(object sender, RoutedEventArgs e)
        {

        }
    }
}
